package com.prm.footballplayers.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFF45B8B4)
val PurpleGrey80 = Color(0xFF3A89C9)
val Pink80 = Color(0xFF7FD2D8)

val Purple40 = Color(0xFF36ABAF)
val PurpleGrey40 = Color(0xFF74B6B6)
val Pink40 = Color(0xFF7FC0BA)