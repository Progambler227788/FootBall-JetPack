package com.prm.footballplayers

data class ClubResponse(val teams: List<Club>)
