package com.prm.footballplayers.dataclasses

data class ListLeaguesData (val leagues : List<LeagueData>)
