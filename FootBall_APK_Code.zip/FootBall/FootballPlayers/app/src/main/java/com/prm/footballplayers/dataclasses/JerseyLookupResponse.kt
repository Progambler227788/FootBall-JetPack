package com.prm.footballplayers.dataclasses

data class JerseyLookupResponse(val equipment: List<JerseyData>)
