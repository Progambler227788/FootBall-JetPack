package com.prm.footballplayers.dataclasses

data class ClubSearchResponse(val clubs: List<ClubData>)
